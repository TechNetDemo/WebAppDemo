package com.technet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

/**
 * Servlet implementation class ConnectDB
 */
public class ConnectDB extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConnectDB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Drive found");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found: " + e);
		}
		String url = "jdbc:mysql://localhost:3306/sakila";
		String user = "root";
		String password = "root";
		String dbname = "film";

		try {
			Connection con = null;

			con = DriverManager.getConnection(url, user, password);
			System.out.println("Connection Success");
			Statement statement = con.createStatement();
			PrintWriter out = response.getWriter();

			String sql = "Select * from " + dbname;
			ResultSet rs = statement.executeQuery(sql);

			out.println("<html><body bgcolor='00aa00'>");
			String[] idArray = new String[1000];

			String str1 = "3a";
			for (int i = 0; rs.next(); i++) {
				String film_id = rs.getString("film_id");
				String title = rs.getString("title");
				String description = rs.getString("description");

				idArray[i] = film_id;

				out.println("<p>(" + idArray[i] + ")" + title + "<br> ("
						+ description + ")</p>");
				// out.println("<tr><td>"+ film_id +"</td><td>" + title +
				// "</td><td>" + description + ")</td></tr>");

			}

			out.println("</body></html>");
			
			
			
			request.setAttribute("str1", str1);
			request.setAttribute("idArray", idArray);
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
			return;

		} catch (SQLException e) {
			System.out.println("Connection string misconfigured?: " + e);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * protected void doPost(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub }
	 */

}
